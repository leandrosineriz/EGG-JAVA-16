
package libreria;

// @author User

import java.util.Scanner;

public class Libreria {

    public static void main(String[] args) {

        Scanner leer = new Scanner(System.in);
        


    }

}
